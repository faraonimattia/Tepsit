package pkg;

public class ThreadManager {

	public static void main(String[] args) {
		buffer coda = new buffer();
		Consumatore c = new Consumatore(coda);
		Produttore p = new Produttore(coda);
		 
		Thread t = new Thread(c);
		Thread t1 = new Thread(p);
		t.start();
		t1.start();
		
		
		while(true) {
			synchronized(coda) {
			System.out.println(coda.getCoda());
			}
		}
	}
	
}
 