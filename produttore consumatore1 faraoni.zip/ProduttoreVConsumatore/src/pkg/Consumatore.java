package pkg;

public class Consumatore implements Runnable{
	
	buffer a;
	
	public Consumatore(buffer a) {
		this.a = a;
	}
	
public void run() {
	while(true) {
		a.Remove();
		try {
		Thread.sleep(300);
		}catch(Exception e) {
			
		}
	}
	}

}
