package pkg;

import java.util.LinkedList;
import java.util.Queue;

public class buffer {

	private Queue<Integer> coda = new LinkedList<>();
	
	synchronized public void Remove() {
		if(coda.isEmpty()) {
			try {
			wait();
			}catch(InterruptedException e) {
				
			}
			}else{
				coda.remove();
			}
		
		}
		
	
	synchronized public void Add() {
		coda.add(1);
		notifyAll();
	}

	synchronized public Queue<Integer> getCoda() {
		return coda;
	}
	
}
