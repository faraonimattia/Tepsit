package pkg;

public class Produttore implements Runnable{

	buffer a;
	
	public Produttore(buffer a) {
		this.a = a;
	}
	
	public void run() {
		while(true) {
		a.Add();
		try {
		Thread.sleep(200);
		}catch(Exception e) {
			
		}}
		
	}
}
