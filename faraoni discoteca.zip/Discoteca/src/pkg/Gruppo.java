package pkg;

import java.util.Random;

class Gruppo implements Runnable {
    private final Discoteca discoteca;
    private final int gruppoID;
    private final int numeroPersone;

    public Gruppo(Discoteca discoteca, int gruppoID, int numeroPersone) {
        this.discoteca = discoteca;
        this.gruppoID = gruppoID;
        this.numeroPersone = numeroPersone;
    }

    public void run() {
        Random rand = new Random();

        while (true) {
            try {
                
                discoteca.entra(gruppoID, numeroPersone);
   
                int tempoDentro = rand.nextInt(5000) + 1000;
                Thread.sleep(tempoDentro);

                discoteca.esci(gruppoID, numeroPersone);

                int tempoFuori = rand.nextInt(3000) + 1000;
                Thread.sleep(tempoFuori);

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
