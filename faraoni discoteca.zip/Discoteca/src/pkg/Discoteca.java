package pkg;

import java.util.LinkedList;
import java.util.Queue;

class Discoteca {
    private final int CAPACITA = 161; // Capienza massima della discoteca
    private int personeDentro = 0; // Persone attualmente dentro
    private final Queue<Integer> attesa = new LinkedList<>(); // Gruppi in attesa

    public synchronized boolean entra(int gruppoID, int numeroPersone) throws InterruptedException {
        while (personeDentro + numeroPersone > CAPACITA) {
            System.out.println("Gruppo " + gruppoID + " in attesa di entrare. Persone attualmente dentro: " + personeDentro);
            attesa.add(gruppoID); // 
            wait(); // Cosa da dire
        }

        personeDentro += numeroPersone;
        System.out.println("Gruppo " + gruppoID + " è entrato. Persone attualmente dentro: " + personeDentro);
        attesa.remove(gruppoID);
        return true;
    }

    public synchronized void esci(int gruppoID, int numeroPersone) {
        personeDentro -= numeroPersone;
        System.out.println("Gruppo " + gruppoID + " è uscito. Persone attualmente dentro: " + personeDentro);
        notifyAll(); // Cosa da dire
    }

    public int getPersoneDentro() {
        return personeDentro;
    }

    public Queue<Integer> getGruppiInAttesa() {
        return new LinkedList<>(attesa);
    }
}

