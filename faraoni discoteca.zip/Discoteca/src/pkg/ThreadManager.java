package pkg;

import java.util.Queue;
import java.util.Random;

class ThreadManager {
    public static void main(String[] args) {
        Discoteca discoteca = new Discoteca();

        // Numero di gruppi e dimensione di ciascun gruppo
        int numeroGruppi = 19;
        int dimensioneGruppoMin = 5;
        int dimensioneGruppoMax = 30;

        // Creazione e avvio dei thread
        for (int i = 1; i <= numeroGruppi; i++) {
            int numeroPersone = new Random().nextInt(dimensioneGruppoMax - dimensioneGruppoMin + 1) + dimensioneGruppoMin;
            Gruppo gruppo = new Gruppo(discoteca, i, numeroPersone);
            new Thread(gruppo).start();
        }

        // Stampa dello stato ogni secondo
        while (true) {
            try {
                Thread.sleep(1000);
                System.out.println("Persone dentro la discoteca: " + discoteca.getPersoneDentro());
                Queue<Integer> gruppiInAttesa = discoteca.getGruppiInAttesa();
                System.out.println("Gruppi in attesa: " + gruppiInAttesa);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}

