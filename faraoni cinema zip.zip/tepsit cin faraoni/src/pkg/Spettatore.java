package pkg;

public class Spettatore implements Runnable {
    private Cinema cinema;

    // Costruttore: ogni spettatore ha accesso al cinema condiviso
    public Spettatore(Cinema cinema) {
        this.cinema = cinema;
    }

    @Override
    public void run() {
        // Ogni spettatore prova a prenotare un posto
        boolean successo = cinema.prenotaPosto();

        // Se la prenotazione non è riuscita, stampa che lo spettacolo è esaurito
        if (!successo) {
            System.out.println("Lo spettacolo è esaurito, non ci sono più posti disponibili.");
        }
    }
}
