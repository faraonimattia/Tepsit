package pkg;

public class Main {
    public static void main(String[] args) {
        // Crea un oggetto Cinema
        Cinema cinema = new Cinema();

        // Crea un array per contenere 7 thread
        Thread[] threads = new Thread[7];

        // Crea e avvia i 7 thread per simulare gli spettatori
        for (int i = 0; i < 7; i++) {
            threads[i] = new Thread(new Spettatore(cinema)); // Passa l'oggetto cinema condiviso
            threads[i].start(); // Avvia il thread
        }

        // Aspetta che tutti i thread finiscano
        for (int i = 0; i < 7; i++) {
            try {
                threads[i].join(); // Attende la terminazione di ogni thread
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Simula l'inizio dello spettacolo dopo 10 secondi
        try {
            System.out.println("Lo spettacolo inizia tra 10 secondi...");
            Thread.sleep(10000); // Pausa di 10 secondi
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Stampa i posti rimanenti
        System.out.println("Posti disponibili rimasti: " + cinema.postiDisponibili());
    }
}
