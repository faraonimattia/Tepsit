package pkg;

public class Cinema {
	
	    // Numero di file e posti per fila
	    private final int file = 15;
	    private final int postiPerFila = 46;

	    // Array 2D per rappresentare i posti: true se prenotato, false se libero
	    private boolean[][] posti;

	    public Cinema() {
	        posti = new boolean[file][postiPerFila]; // Inizializza tutti i posti come disponibili (false)
	    }

	    // Metodo sincronizzato per prenotare i posti vicini al centro
	    public synchronized boolean prenotaPosto() {
	        for (int i = 0; i < file; i++) {
	            int centro = postiPerFila / 2; // Calcolo della posizione centrale di ogni fila
	            // Ciclo per trovare il posto libero più vicino al centro
	            for (int j = 0; j < postiPerFila; j++) {
	                int sinistra = centro - j;  // Verifica verso sinistra dal centro
	                int destra = centro + j;    // Verifica verso destra dal centro

	                // Prenota posto a sinistra se libero
	                if (sinistra >= 0 && !posti[i][sinistra]) {
	                    posti[i][sinistra] = true;
	                    System.out.println("Prenotato posto: Fila " + (i + 1) + ", Posto " + (sinistra + 1));
	                    return true;
	                }

	                // Prenota posto a destra se libero
	                if (destra < postiPerFila && !posti[i][destra]) {
	                    posti[i][destra] = true;
	                    System.out.println("Prenotato posto: Fila " + (i + 1) + ", Posto " + (destra + 1));
	                    return true;
	                }
	            }
	        }
	        // Se non ci sono posti liberi, ritorna false
	        return false;
	    }

	    // Metodo per calcolare il numero di posti rimanenti
	    public synchronized int postiDisponibili() {
	        int postiLiberi = 0;
	        for (int i = 0; i < file; i++) {
	            for (int j = 0; j < postiPerFila; j++) {
	                if (!posti[i][j]) {
	                    postiLiberi++;
	                }
	            }
	        }
	        return postiLiberi;
	    }
	}



